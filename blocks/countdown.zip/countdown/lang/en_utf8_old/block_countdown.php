<?PHP // $Id: block_coundown.php,v 1.0 2007/03/01 09:37:06 moodler Exp $ 

$string['newcountdownblock'] = 'New Countdown';
$string['configshowheader'] = 'Show header';
$string['countdown'] = 'Countdown';
$string['configtitle'] = 'Title';
$string['configtimesource'] = 'Time Source';
$string['server'] = 'Server Time';
$string['usercomputer'] = 'User\'s computer';
$string['configcontentabove'] = 'Text above Countdown';
$string['configcontentbelow'] = 'Text below Countdown';
$string['configdate'] = 'Day';
$string['configmonth'] = 'Month';
$string['configyear'] = 'Year';
$string['confighour'] = 'Hour';
$string['configminute'] = 'Minute';
$string['configdigitcolor'] = 'Digit Colour';
$string['configbgcolor'] = 'Background Colour';
$string['configtextcolor'] = 'Text Colour';
$string['startyear'] = 'Start Year';
$string['endyear'] = 'End Year';
$string['width'] = 'Width';
$string['height'] = 'Height';
$string['default'] = 'Default';
$string['annual'] = 'annual';
$string['days'] = 'days';
$string['minutes'] = 'mins';
$string['hours'] = 'hrs';
$string['seconds'] = 'secs';
$string['longdays'] = 'days';
$string['longminutes'] = 'minutes';
$string['longhours'] = 'hours';
$string['longseconds'] = 'seconds';
$string['clock'] = 'Clock Style';
$string['finishtext'] = 'Time reached message';
?>
